package ru.antimoshennik.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private final int green = Color.rgb(11, 61, 46);
    private final int mint = Color.rgb(22, 132, 91);
    private final int pale = Color.rgb(237, 247, 241);
    private LinearLayout page;
    private SharedPreferences prefs;
    private EditText input;
    private String currentMode = "SMS";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("anti_moshennik", MODE_PRIVATE);
        showHome();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(2), dp(4), dp(2), dp(4)); return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(12), dp(18), dp(20)); return l;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void base(String title, String subtitle) {
        ScrollView scroll = new ScrollView(this);
        page = column(); page.setBackgroundColor(Color.WHITE);
        TextView h = text(title, 26, green, true); h.setPadding(0, dp(12), 0, dp(2)); page.addView(h);
        page.addView(text(subtitle, 14, Color.DKGRAY, false));
        View line = new View(this); line.setBackgroundColor(mint);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(2)); lp.topMargin=dp(8); lp.bottomMargin=dp(12);
        page.addView(line, lp); scroll.addView(page);
        setContentView(scroll);
    }
    private void card(String title, String desc, Runnable action) {
        LinearLayout box = column(); box.setPadding(dp(14), dp(10), dp(14), dp(10)); box.setBackgroundColor(pale);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin=dp(10);
        page.addView(box, lp); box.addView(text(title,18,green,true)); box.addView(text(desc,14,Color.DKGRAY,false));
        box.addView(button("Открыть", action));
    }
    private void showHome() {
        base("Анти-Мошенник", "Локальная проверка подозрительных сообщений и ссылок");
        page.addView(text("Проверяйте до того, как нажать, ответить или перевести деньги.",16,green,true));
        card("Проверка SMS и текста", "Анализ срочности, просьб о деньгах, кодах и личных данных.", () -> showAnalyzer("SMS / текст"));
        card("Проверка ссылки", "Проверка адреса на распространённые признаки фишинга.", () -> showAnalyzer("Ссылка"));
        card("Проверка номера", "Сопоставление с локальным списком известных подозрительных номеров.", () -> showAnalyzer("Номер"));
        card("Разбор разговора", "Вставьте расшифровку звонка, чтобы найти признаки давления и обмана.", () -> showAnalyzer("Разговор"));
        card("История проверок", "Посмотреть сохранённые результаты на этом устройстве.", this::showHistory);
        card("Настройки интеграции", "Поле для будущего подключения внешнего ИИ API.", this::showSettings);
        page.addView(text("Важно: это помощник для оценки риска, а не гарантия обнаружения мошенничества. Не сообщайте коды подтверждения и пароли никому.",12,Color.GRAY,false));
    }
    private void showAnalyzer(String mode) {
        currentMode = mode;
        base(mode, "Данные анализируются на устройстве; ничего не отправляется в интернет.");
        page.addView(text(mode.equals("Номер") ? "Введите номер телефона" :
                mode.equals("Ссылка") ? "Вставьте полный URL" :
                mode.equals("Разговор") ? "Вставьте текст или расшифровку разговора" : "Вставьте текст сообщения",15,green,true));
        input = new EditText(this); input.setMinLines(mode.equals("Номер") || mode.equals("Ссылка") ? 1 : 4);
        input.setGravity(Gravity.TOP); input.setHint(mode.equals("Номер") ? "+7..." : mode.equals("Ссылка") ? "https://..." : "Текст для проверки…");
        input.setInputType(mode.equals("Номер") ? InputType.TYPE_CLASS_PHONE : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        page.addView(input, new LinearLayout.LayoutParams(-1,-2));
        page.addView(button("Проверить", () -> analyze(input.getText().toString().trim(), mode)));
        page.addView(button("← На главную", this::showHome));
    }
    private void analyze(String value, String mode) {
        if (value.isEmpty()) { Toast.makeText(this,"Сначала введите данные",Toast.LENGTH_SHORT).show(); return; }
        int score = 0; ArrayList<String> reasons = new ArrayList<>();
        String s = value.toLowerCase(Locale.ROOT);
        if (mode.equals("Номер")) {
            String digits = value.replaceAll("\\D","");
            String known = prefs.getString("blocked_numbers", "");
            if (!digits.isEmpty() && known.contains(digits)) { score += 75; reasons.add("Номер совпал с локальным списком подозрительных номеров."); }
            else reasons.add("Номер не найден в локальном списке. Это не означает, что он безопасен.");
            if (digits.length() < 7 || digits.length() > 15) { score += 15; reasons.add("Необычная длина номера."); }
        } else if (mode.equals("Ссылка")) {
            if (!s.matches("^https?://.*")) { score += 20; reasons.add("Нет явного протокола http:// или https://."); }
            if (s.contains("@")) { score += 25; reasons.add("Символ @ в адресе может маскировать настоящий домен."); }
            if (s.matches(".*https?://\\d{1,3}(\\.\\d{1,3}){3}.*")) { score += 25; reasons.add("В адресе используется IP вместо обычного доменного имени."); }
            if (s.contains("xn--")) { score += 20; reasons.add("Домен содержит Punycode; проверьте написание особенно внимательно."); }
            if (s.contains("bit.ly") || s.contains("tinyurl") || s.contains("t.co/") || s.contains("cutt.ly")) { score += 20; reasons.add("Используется сокращатель ссылок, скрывающий конечный адрес."); }
            if (s.contains("login") || s.contains("verify") || s.contains("secure") || s.contains("account") || s.contains("bonus") || s.contains("prize")) { score += 10; reasons.add("В адресе есть слова, часто встречающиеся в приманках; сами по себе они не доказывают обман."); }
            if (s.startsWith("http://")) { score += 10; reasons.add("Соединение использует HTTP без шифрования."); }
            if (reasons.isEmpty()) reasons.add("Очевидных признаков из базового набора не найдено; всё равно проверьте домен вручную.");
        } else {
            String[][] rules = {
                {"срочно","Срочность или давление на пользователя."},
                {"немедленно","Требование действовать немедленно."},
                {"код из смс","Запрос кода подтверждения."},
                {"код подтверждения","Запрос кода подтверждения."},
                {"назовите код","Просьба сообщить секретный код."},
                {"пароль","Упоминание пароля или доступа к аккаунту."},
                {"переведите деньги","Просьба перевести деньги."},
                {"безопасный счет","Упоминание «безопасного счёта» — распространённый тревожный признак."},
                {"служба безопасности","Ссылка на службу безопасности без проверяемого подтверждения."},
                {"заблокируем","Угроза блокировки или потери доступа."},
                {"ваш аккаунт","Упоминание аккаунта в потенциально тревожном контексте."},
                {"вы выиграли","Сообщение о неожиданном выигрыше."},
                {"оплатите доставку","Просьба оплатить доставку по сообщению."},
                {"перейдите по ссылке","Побуждение перейти по ссылке."},
                {"паспорт","Запрос персональных данных."},
                {"cvv","Запрос данных банковской карты."},
                {"cvc","Запрос данных банковской карты."},
                {"одноразовый код","Запрос одноразового кода."}
            };
            for (String[] rule : rules) if (s.contains(rule[0])) { score += 12; reasons.add(rule[1]); }
            if (s.contains("банк") && (s.contains("перев") || s.contains("код") || s.contains("счет") || s.contains("счёт"))) {
                score += 12; reasons.add("Банк упоминается вместе с финансовым действием или кодом.");
            }
            if (reasons.isEmpty()) reasons.add("Типовые тревожные фразы не обнаружены. Автоматическая проверка не может подтвердить безопасность текста.");
        }
        score = Math.min(100, score);
        String level = score >= 60 ? "ВЫСОКИЙ РИСК" : score >= 30 ? "ПОВЫШЕННЫЙ РИСК" : "НИЗКИЙ РИСК ПО ЭТИМ ПРИЗНАКАМ";
        saveHistory(mode, value, score, level);
        base("Результат проверки", "Тип: " + mode);
        TextView risk = text(level + " · " + score + "/100",20,score>=60?Color.rgb(180,35,35):score>=30?Color.rgb(180,105,0):mint,true);
        page.addView(risk);
        page.addView(text("Обнаруженные признаки",17,green,true));
        for (String reason : reasons) page.addView(text("• " + reason,15,Color.DKGRAY,false));
        page.addView(text("Что делать дальше",17,green,true));
        page.addView(text("• Не сообщайте пароли, PIN-коды и коды из SMS.\n• Не переводите деньги по инструкции звонящего.\n• Откройте официальный сайт или приложение самостоятельно.\n• Свяжитесь с организацией по номеру с её официального сайта.\n• При сомнениях прекратите разговор и посоветуйтесь с доверенным человеком.",14,Color.DKGRAY,false));
        page.addView(button("Проверить ещё", () -> showAnalyzer(mode)));
        page.addView(button("На главную", this::showHome));
    }
    private void saveHistory(String mode, String value, int score, String level) {
        try {
            JSONArray arr = new JSONArray(prefs.getString("history","[]"));
            JSONObject o = new JSONObject(); o.put("mode",mode); o.put("value",value.length()>160?value.substring(0,160)+"…":value);
            o.put("score",score); o.put("level",level);
            o.put("date",new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new Date()));
            arr.put(o); while (arr.length()>50) { JSONArray n=new JSONArray(); for(int i=1;i<arr.length();i++) n.put(arr.get(i)); arr=n; }
            prefs.edit().putString("history",arr.toString()).apply();
        } catch(Exception ignored) {}
    }
    private void showHistory() {
        base("История проверок", "Последние 50 результатов хранятся локально на устройстве.");
        try {
            JSONArray arr = new JSONArray(prefs.getString("history","[]"));
            if (arr.length()==0) page.addView(text("Пока нет проверок.",15,Color.DKGRAY,false));
            for(int i=arr.length()-1;i>=0;i--) {
                JSONObject o=arr.getJSONObject(i);
                page.addView(text(o.optString("date")+" · "+o.optString("mode"),14,green,true));
                page.addView(text(o.optString("level")+" ("+o.optInt("score")+"/100)\n"+o.optString("value"),14,Color.DKGRAY,false));
                View v=new View(this); v.setBackgroundColor(0xFFE0E0E0); page.addView(v,new LinearLayout.LayoutParams(-1,dp(1)));
            }
        } catch(Exception e) { page.addView(text("Не удалось прочитать историю.",14,Color.RED,false)); }
        page.addView(button("Очистить историю", () -> new AlertDialog.Builder(this).setTitle("Очистить историю?")
                .setMessage("Все сохранённые результаты будут удалены.")
                .setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{prefs.edit().remove("history").apply();showHistory();}).show()));
        page.addView(button("На главную",this::showHome));
    }
    private void showSettings() {
        base("Настройки интеграции", "Локальная версия работает без токена ChatGPT.");
        page.addView(text("Точка подключения ИИ API",16,green,true));
        page.addView(text("В этой сборке сетевой вызов ИИ намеренно не включён. Поле ниже сохраняет заметку о настройке, но не отправляет запросы и не проверяет ключ.",14,Color.DKGRAY,false));
        EditText endpoint = new EditText(this); endpoint.setHint("URL API (например, https://…)");
        endpoint.setText(prefs.getString("api_endpoint","")); page.addView(endpoint);
        EditText token = new EditText(this); token.setHint("API-токен (добавите позже)"); token.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setText(prefs.getString("api_token","")); page.addView(token);
        page.addView(button("Сохранить настройки", () -> {
            prefs.edit().putString("api_endpoint",endpoint.getText().toString().trim())
                    .putString("api_token",token.getText().toString()).apply();
            Toast.makeText(this,"Сохранено на устройстве",Toast.LENGTH_SHORT).show();
        }));
        page.addView(text("Безопасность: токен в этой заготовке сохраняется в обычных настройках приложения. Не используйте реальный ключ, пока не будет добавлено шифрованное хранение и сетевой модуль.",12,Color.rgb(160,50,30),true));
        page.addView(text("Локальный список номеров",16,green,true));
        page.addView(text("Добавьте номера через запятую. Это частный список на устройстве, не общая база и не доказательство мошенничества.",14,Color.DKGRAY,false));
        EditText numbers = new EditText(this); numbers.setHint("+79990000000, +78005553535"); numbers.setText(prefs.getString("blocked_numbers","")); numbers.setMinLines(2); page.addView(numbers);
        page.addView(button("Сохранить список номеров", () -> {prefs.edit().putString("blocked_numbers",numbers.getText().toString().replaceAll("\\D+"," ")).apply();Toast.makeText(this,"Список сохранён",Toast.LENGTH_SHORT).show();}));
        page.addView(button("На главную",this::showHome));
    }
}
